<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>MainCapt</name>
    <message>
        <location filename="maincapt.ui" line="20"/>
        <source>Capt 2.4</source>
        <oldsource>Capt 2.4.4</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="27"/>
        <location filename="maincapt.ui" line="49"/>
        <location filename="maincapt.ui" line="7238"/>
        <location filename="maincapt.ui" line="7360"/>
        <location filename="maincapt.ui" line="7384"/>
        <location filename="maincapt.ui" line="7392"/>
        <location filename="maincapt.ui" line="7419"/>
        <source>Capt 2.4 criado por Yvanowik D. Valério</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="83"/>
        <source>Capt 2.4 Controles de coleta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="110"/>
        <source>Capt 2.4 Controles de coleta - Opções</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="113"/>
        <location filename="maincapt.ui" line="7249"/>
        <source>Controle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="162"/>
        <source>Tratamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="193"/>
        <source>Painel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="221"/>
        <source>Expressão (ER)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="238"/>
        <source>Padrão máximo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="256"/>
        <source>Operações</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="276"/>
        <source>Inserir antes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="293"/>
        <source>Anexar no começo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="307"/>
        <source>Exibir dados (tipos ou casos)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="324"/>
        <source>Gerar corpus em uma ou em múltiplas pastas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="327"/>
        <source>Coletar para múltiplas pastas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="347"/>
        <source>Estatística</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="376"/>
        <location filename="maincapt.ui" line="7449"/>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="398"/>
        <source>Unidade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="433"/>
        <source>Palavra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="447"/>
        <source>Inclua uma expressão regular para as palavras</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="467"/>
        <location filename="maincapt.ui" line="515"/>
        <location filename="maincapt.ui" line="563"/>
        <location filename="maincapt.ui" line="1579"/>
        <location filename="maincapt.ui" line="2928"/>
        <location filename="maincapt.ui" line="4559"/>
        <location filename="maincapt.ui" line="4800"/>
        <location filename="maincapt.ui" line="5038"/>
        <location filename="maincapt.ui" line="6150"/>
        <source>[ ok ]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="481"/>
        <source>Sentença</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="495"/>
        <source>Inclua uma expressão regular para as sentenças</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="529"/>
        <source>Parágrafo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="543"/>
        <source>Inclua uma expressão regular para os parágrafos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="580"/>
        <location filename="maincapt.ui" line="7467"/>
        <source>Legibilidade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="599"/>
        <source>Fórmula</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="628"/>
        <source>Recorte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="656"/>
        <source>Fator de distribuição</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="659"/>
        <source>Fator </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="686"/>
        <source>Norma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="717"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="742"/>
        <source>Processamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="771"/>
        <source>Categorização</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="790"/>
        <source>Grupo 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="804"/>
        <location filename="maincapt.ui" line="856"/>
        <source>Inclua variáveis para categorizar itens da amostra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="821"/>
        <location filename="maincapt.ui" line="873"/>
        <location filename="maincapt.ui" line="6184"/>
        <location filename="maincapt.ui" line="6233"/>
        <source>[0]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="842"/>
        <source>Grupo 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="895"/>
        <source>Salvar opções em</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="925"/>
        <source>Diretório</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="939"/>
        <source>Onde salvar internamente?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="956"/>
        <source>Com que nome salvar internamente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="973"/>
        <location filename="maincapt.ui" line="7242"/>
        <source>Arquivo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1009"/>
        <source>Capt 2.4 Controles de coleta - Corpus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1012"/>
        <location filename="maincapt.ui" line="7274"/>
        <source>Corpus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1050"/>
        <source>Nenhum texto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1062"/>
        <source>Clique duplo ou Enter para abrir a Fonte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1094"/>
        <source>Opções de Arquivo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1124"/>
        <source>Codificação</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1158"/>
        <source>Capt 2.4 Controles de coleta - ER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1161"/>
        <location filename="maincapt.ui" line="7260"/>
        <source>g/RE/p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1198"/>
        <source>Inclua uma expressão regular (tecle Enter para executar a busca)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1208"/>
        <source>(\.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1241"/>
        <source>Opções de Contexto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1269"/>
        <source>Intervalo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1294"/>
        <source>&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1341"/>
        <source>&lt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1366"/>
        <source>Tipo de Contexto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1400"/>
        <source>Incluir unidades</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1425"/>
        <source> antes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1451"/>
        <source> depois</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1454"/>
        <source> e </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1476"/>
        <source>Descartar coocorrentes </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1495"/>
        <source>Antes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1515"/>
        <source>Depois</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1537"/>
        <source>Referência (ER)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1556"/>
        <location filename="maincapt.ui" line="4556"/>
        <source>Inclua uma ER que referencia o caso coletado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1602"/>
        <source>Capt 2.4 Controles de coleta - Regras</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1605"/>
        <source>Regras</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1613"/>
        <source>Modo de aplicação</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1623"/>
        <source>Nenhuma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1636"/>
        <source>Regra 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1674"/>
        <location filename="maincapt.ui" line="1767"/>
        <location filename="maincapt.ui" line="1860"/>
        <source>Não se aplica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1709"/>
        <source>Inclua o(s) critério(s) da regra 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1726"/>
        <location filename="maincapt.ui" line="1819"/>
        <location filename="maincapt.ui" line="1912"/>
        <source>Use , ou ; para separar vários critérios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1738"/>
        <source>Regra 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1802"/>
        <source>Inclua o(s) critério(s) da regra 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1831"/>
        <source>Regra 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1895"/>
        <source>Inclua o(s) critério(s) da regra 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1948"/>
        <source>Capt 2.4 Controles de coleta - Registro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1951"/>
        <source>Registro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1971"/>
        <source>Detalhamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1991"/>
        <source>Nenhum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="1994"/>
        <source> feitos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2016"/>
        <location filename="maincapt.ui" line="2019"/>
        <source>Limpar registro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2072"/>
        <source>[pronto]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2166"/>
        <source>Capt 2.4 Mostruário de itens coletados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2191"/>
        <source>Dados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2244"/>
        <location filename="maincapt.ui" line="5791"/>
        <source>Fonte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2274"/>
        <source>Faça BACK-UP dos seus textos antes de submetê-los ao CAPT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2292"/>
        <source>Lin 0, Col 0, Pos 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2332"/>
        <source>Capt 2.4 Processamento de itens coletados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2357"/>
        <source>Capt 2.4 Preparação de fontes e itens coletados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2395"/>
        <location filename="maincapt.ui" line="5448"/>
        <source>Ir para Análises</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2398"/>
        <location filename="maincapt.ui" line="4010"/>
        <location filename="maincapt.ui" line="5372"/>
        <location filename="maincapt.ui" line="6640"/>
        <source>⮜</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2422"/>
        <source>1 Preparação</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2432"/>
        <location filename="maincapt.ui" line="5397"/>
        <location filename="maincapt.ui" line="6665"/>
        <source>Refinamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2446"/>
        <location filename="maincapt.ui" line="4058"/>
        <location filename="maincapt.ui" line="6679"/>
        <source>Amostragem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2460"/>
        <location filename="maincapt.ui" line="4072"/>
        <location filename="maincapt.ui" line="5434"/>
        <source>Análises</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2474"/>
        <location filename="maincapt.ui" line="5369"/>
        <source>Ir para Refinamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2480"/>
        <location filename="maincapt.ui" line="4089"/>
        <location filename="maincapt.ui" line="5451"/>
        <location filename="maincapt.ui" line="6719"/>
        <source>⮞</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2539"/>
        <location filename="maincapt.ui" line="4145"/>
        <location filename="maincapt.ui" line="5507"/>
        <source>Navegador dos dados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2568"/>
        <location filename="maincapt.ui" line="4177"/>
        <location filename="maincapt.ui" line="5536"/>
        <source>Coletados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2605"/>
        <location filename="maincapt.ui" line="4205"/>
        <location filename="maincapt.ui" line="5567"/>
        <source>Item </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2625"/>
        <location filename="maincapt.ui" line="4231"/>
        <location filename="maincapt.ui" line="5593"/>
        <location filename="maincapt.ui" line="6335"/>
        <source>Primeiro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2652"/>
        <location filename="maincapt.ui" line="4258"/>
        <location filename="maincapt.ui" line="5620"/>
        <location filename="maincapt.ui" line="6362"/>
        <source>Anterior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2679"/>
        <location filename="maincapt.ui" line="4285"/>
        <location filename="maincapt.ui" line="5647"/>
        <location filename="maincapt.ui" line="6389"/>
        <source>Próximo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2724"/>
        <location filename="maincapt.ui" line="4312"/>
        <location filename="maincapt.ui" line="5674"/>
        <location filename="maincapt.ui" line="6416"/>
        <source>Último</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2751"/>
        <source>Apaga itens coletados (sem salvar)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2757"/>
        <source>Limpar dados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2785"/>
        <source>Tratamento da fonte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2840"/>
        <source>padrão máximo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2854"/>
        <source>inserir antes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2874"/>
        <source>Expressão de busca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2899"/>
        <source>ExpReg para buscas na fonte aberta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2951"/>
        <source>Anterior (ctrl+shift+g)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2961"/>
        <source>Ctrl+Shift+G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="2990"/>
        <source> Mostrar na fonte </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3010"/>
        <source>Próxima (ctrl+g)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3020"/>
        <source>Ctrl+G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3059"/>
        <source>Dividir o texto da fonte em linhas tomando a ER como critério</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3062"/>
        <source>Listar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3085"/>
        <source>Tipificar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3108"/>
        <source>Texto para trocar ou inserir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3133"/>
        <source>Texto a ser usado para troca ou inserção</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3166"/>
        <source>Desfazer a última operação</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3169"/>
        <source>Desfazer 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3205"/>
        <source>Eliminar todas as ocorrências da ER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3208"/>
        <source>Apagar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3231"/>
        <source>Substituir a ER encontrada pelo texto modificador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3234"/>
        <location filename="maincapt.ui" line="7869"/>
        <source>Trocar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3257"/>
        <source>Inserir o texto modificador antes ou depois da ER encontrada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3260"/>
        <location filename="maincapt.ui" line="7943"/>
        <source>Inserir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3282"/>
        <source>Coleta avulsa de dados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3320"/>
        <source>Da fonte para a tabela (↑)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3348"/>
        <source>Rótulo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3374"/>
        <source>Nome para a coluna de dados coletados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3403"/>
        <location filename="maincapt.ui" line="3647"/>
        <source>Linha na tabela de dados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3418"/>
        <source>Linha </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3450"/>
        <location filename="maincapt.ui" line="3603"/>
        <source>Coluna na tabela de dados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3462"/>
        <location filename="maincapt.ui" line="6951"/>
        <source>Coluna </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3511"/>
        <source>Copiar a ocorrência da ER para diferentes colunas na tabela de dados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3514"/>
        <source>Coletar achado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3517"/>
        <source>Ctrl+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3540"/>
        <source>Copiar todas as ocorrências da ER para uma única coluna na tabela de dados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3543"/>
        <source>Coletar todos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3546"/>
        <source>Ctrl+T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3578"/>
        <source>Da tabela para a fonte (↓)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3615"/>
        <source>Da coluna </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3653"/>
        <source>até a </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3679"/>
        <source>Copiar uma coluna da tabela de dados para a fonte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3682"/>
        <source>Copiar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3704"/>
        <source>Concatenação de fontes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3749"/>
        <source>Limpar fonte (sem salvar)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3752"/>
        <source>Limpar fonte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3788"/>
        <source>Anexar o texto selecionado à fonte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3791"/>
        <source>Juntar uma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3814"/>
        <source>Concatenar todos os textos à fonte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3817"/>
        <source>Juntar todas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3862"/>
        <source>Gravação da fonte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3904"/>
        <source>Salvar o arquivo que estiver aberto na fonte (ctrl+s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3907"/>
        <source>Salvar fonte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3910"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3946"/>
        <source>Salvar o conteúdo da fonte para novo arquivo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3949"/>
        <source>Salvar fonte como</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="3969"/>
        <source>Capt 2.4 Filtragem de itens coletados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4007"/>
        <location filename="maincapt.ui" line="6716"/>
        <source>Ir para Preparação</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4021"/>
        <location filename="maincapt.ui" line="5383"/>
        <location filename="maincapt.ui" line="6651"/>
        <source>Preparação</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4048"/>
        <source>2 Refinamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4086"/>
        <location filename="maincapt.ui" line="6637"/>
        <source>Ir para Amostragem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4339"/>
        <source>Excluir o registro atual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4342"/>
        <location filename="maincapt.ui" line="6446"/>
        <source>Excluir item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4370"/>
        <source>Filtro 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4412"/>
        <location filename="maincapt.ui" line="4650"/>
        <location filename="maincapt.ui" line="4891"/>
        <source>Tipo (texto)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4450"/>
        <location filename="maincapt.ui" line="4688"/>
        <location filename="maincapt.ui" line="4929"/>
        <source>Campo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4464"/>
        <source>Coluna onde aplicar o filtro 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4500"/>
        <source>Remover todos os filtros</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4530"/>
        <location filename="maincapt.ui" line="4774"/>
        <location filename="maincapt.ui" line="5009"/>
        <source>Critério (TXT/ER) para a filtragem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4579"/>
        <source>Aplicar filtro 1 sobre os dados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4608"/>
        <source>Filtro 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4708"/>
        <source>Coluna onde aplicar o filtro 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4744"/>
        <source>Remover filtros 2 e 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4820"/>
        <source>Aplicar o filtro 2 sobre o 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4849"/>
        <source>Filtro 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4943"/>
        <source>Coluna onde aplicar o filtro 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="4979"/>
        <source>Remover filtro 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5058"/>
        <source>Aplicar o filtro 3 sobre o 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5090"/>
        <source>Exclusão de arquivos de fonte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5129"/>
        <source>O arquivo será enviado para a lixeira</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5132"/>
        <source>Esta operação é irreversível</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5135"/>
        <source>Excluir fonte aberta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5138"/>
        <source>Ctrl+Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5168"/>
        <source>Todos os arquivos filtrados serão enviados para a lixeira</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5171"/>
        <source>Esta operação é automática e irreversível</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5174"/>
        <source>Excluir fontes filtradas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5219"/>
        <source>Gravação dos dados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5255"/>
        <source>Salvar arquivo de dados aberto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5258"/>
        <source>Salvar dados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5288"/>
        <source>Exportar tabela de dados para um arquivo CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5291"/>
        <source>Exportar dados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5308"/>
        <source>Exportar dados filtrados para um arquivo CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5311"/>
        <source>Exportar filtrados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5331"/>
        <source>Capt 2.4 Seleção de itens coletados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5424"/>
        <source>3 Amostragem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5701"/>
        <source>Inclui este registro na seleção</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5704"/>
        <source>Incluir item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5738"/>
        <source>Amostra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5824"/>
        <source>Limpa a amostra (sem salvar)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5827"/>
        <source>Nova amostra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5850"/>
        <source>Contexto na fonte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5911"/>
        <source>Origem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5949"/>
        <source>Termo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="5981"/>
        <source>Contexto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6013"/>
        <source>Marcador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6057"/>
        <source>Categorização dos dados amostrais</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6091"/>
        <source>Grupo 1 Modalidades</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6124"/>
        <source>Guardar alterações (sem salvar)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6127"/>
        <source>Atualizar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6167"/>
        <source>Inclua os códigos de análise do grupo 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6204"/>
        <source>Grupo 2 Modalidades</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6216"/>
        <source>Inclua os códigos de análise do grupo 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6255"/>
        <source>Navegador da amostra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6284"/>
        <source>Selecionados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6443"/>
        <source>Exclui o item atual da seleção</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6481"/>
        <source>Gravação da amostra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6537"/>
        <source>Salvar os dados da amostra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6540"/>
        <source>Salvar amostra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6576"/>
        <source>Abrir uma amostra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6579"/>
        <source>Abrir amostra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6599"/>
        <source>Capt 2.4 Análises experimentais</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6706"/>
        <source>4 Análises</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6775"/>
        <source>Operações de partição</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6820"/>
        <source>Gera agrupamentos de n-gramas para a fonte aberta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6823"/>
        <source>n-gramas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6859"/>
        <source>Gera dados de análise silábica para a fonte aberta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6862"/>
        <source>sílaba</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6884"/>
        <source>Operações estatísticas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="6983"/>
        <source>Rank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7005"/>
        <source>Geração de sequências</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7047"/>
        <source>Incluir antes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7073"/>
        <source>Incluir depois</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7109"/>
        <source>Início </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7138"/>
        <source>Fim </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7165"/>
        <source>Repetir no final da linha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7185"/>
        <source>Gerar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7200"/>
        <source>[Capt] Em construção!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7246"/>
        <source>Ações da aba Controle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7257"/>
        <source>Ações da aba g/RE/p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7271"/>
        <source>Ações da aba Corpus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7285"/>
        <source>Ações sobre itens coletados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7288"/>
        <location filename="maincapt.ui" line="7319"/>
        <location filename="maincapt.ui" line="7357"/>
        <source>Pesquisa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7302"/>
        <source>Ações de edição de corpus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7305"/>
        <source>Editar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7316"/>
        <source>Ações de coleta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7331"/>
        <source>Ações de análise do corpus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7334"/>
        <location filename="maincapt.ui" line="7389"/>
        <source>Análise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7342"/>
        <source>Ações de ajuda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7345"/>
        <source>Ajuda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7416"/>
        <source>Edição</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7446"/>
        <source>Calcular volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7452"/>
        <source>Calcula o volume do corpus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7464"/>
        <source>Calcular legibilidade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7470"/>
        <source>Calcula a legibilidade do corpus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7482"/>
        <source>Contar tipos (em geral)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7485"/>
        <source>Tipos
(em geral)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7489"/>
        <source>Conta ocorrências  para as expressões regulares</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7498"/>
        <source>Coletar casos (referência)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7501"/>
        <source>Casos
(referência)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7505"/>
        <source>Coleta ocorrências para as expressões com contexto próximo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7514"/>
        <source>Coletar casos (coocorrência)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7517"/>
        <source>Casos
(coocorrência)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7521"/>
        <source>Coleta ocorrências para as expressões e conta coocorrentes em contextos distantes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7530"/>
        <source>Reiniciar controle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7533"/>
        <source>Reiniciar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7536"/>
        <source>Retorna todos os controles ao padrão</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7548"/>
        <source>Abrir controles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7551"/>
        <location filename="maincapt.ui" line="7623"/>
        <location filename="maincapt.ui" line="7728"/>
        <location filename="maincapt.ui" line="7851"/>
        <source>Abrir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7554"/>
        <source>Abre controles salvos internamente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7566"/>
        <source>Salvar controles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7569"/>
        <location filename="maincapt.ui" line="7641"/>
        <location filename="maincapt.ui" line="7746"/>
        <location filename="maincapt.ui" line="7815"/>
        <source>Salvar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7572"/>
        <source>Salva internamente os controles de operação</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7584"/>
        <source>Limpar ER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7587"/>
        <location filename="maincapt.ui" line="7692"/>
        <location filename="maincapt.ui" line="7797"/>
        <source>Limpar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7590"/>
        <source>Limpa a lista de expressões regulares</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7602"/>
        <source>Importar ER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7605"/>
        <location filename="maincapt.ui" line="7833"/>
        <source>Importar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7608"/>
        <source>Importa expressões regulares de arquivo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7620"/>
        <source>Abrir ER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7626"/>
        <source>Abre a lista de expressões regulares salva internamente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7638"/>
        <source>Salvar ER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7644"/>
        <source>Salva internamente a lista de expressões regulares</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7656"/>
        <location filename="maincapt.ui" line="7761"/>
        <source>Salvar como</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7659"/>
        <source>Salva a lista de expressões regulares para arquivo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7671"/>
        <source>Incluir ER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7674"/>
        <source>Incluir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7677"/>
        <source>Adiciona expressão regular à lista</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7689"/>
        <source>Limpar corpus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7695"/>
        <source>Limpa a lista para a criação de novo corpus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7707"/>
        <source>Adicionar ao corpus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7710"/>
        <source>Adicionar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7713"/>
        <source>Adiciona arquivos ao corpus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7725"/>
        <source>Abrir corpus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7731"/>
        <source>Abre corpus salvo internamente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7743"/>
        <source>Salvar corpus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7749"/>
        <source>Salva internamente o corpus atual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7764"/>
        <source>Salva o corpus atual para arquivo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7779"/>
        <source>Calcular fraseologia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7782"/>
        <source>Fraseologia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7785"/>
        <source>Calcular a fraseologia do corpus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7794"/>
        <source>Limpar pesquisa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7800"/>
        <source>Apaga todos os itens coletados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7812"/>
        <source>Salvar pesquisa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7818"/>
        <source>Salvar esta sessão de pesquisa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7830"/>
        <source>Importar corpus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7836"/>
        <source>Importa corpus a partir de arquivo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7848"/>
        <source>Abrir pesquisa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7854"/>
        <source>Abrir uma sessão de pesquisa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7866"/>
        <source>Trocar (er:=:nt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7872"/>
        <source>Troca (er:=:nt) o padrão encontrado (er) pelo novo texto (nt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7881"/>
        <source>About Capt</source>
        <translation>Sobre o Capt</translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7884"/>
        <location filename="maincapt.cpp" line="98"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7893"/>
        <source>Cancelar operação</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7896"/>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7899"/>
        <source>Cancela a operação em curso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7908"/>
        <source>Contar tipos (por texto)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7911"/>
        <source>Tipos
(por texto)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7915"/>
        <source>Conta ocorrências para as expressões regulares texto a texto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7924"/>
        <source>Coletar casos (colocação)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7927"/>
        <source>Casos
(colocação)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7931"/>
        <source>Centraliza ocorrências para as expressões com contexto próximo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7940"/>
        <source>Inserir (er:=:nt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7946"/>
        <source>Insere (er:=:nt) novo texto (nt) antes ou depois do padrão encontrado (er)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7955"/>
        <source>Anexar (nt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7958"/>
        <source>Anexar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7961"/>
        <source>Anexa novo texto (nt) no começo ou no fim do arquivo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7970"/>
        <source>Gerar corpus (coletar)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7973"/>
        <source>Gerar corpus
(coleta)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7977"/>
        <source>Coleta ocorrências e grava uma por arquivo na pasta indicada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7986"/>
        <source>Converter (txt→xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7989"/>
        <source>Converter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="7992"/>
        <source>Converte um corpus txt para xml</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="8001"/>
        <source>Concatenar corpus (xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="8004"/>
        <source>Concatenar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="8007"/>
        <source>Concatena um corpus num único arquivo xml</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="8016"/>
        <source>Calcular vocabulário</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="8019"/>
        <source>Vocabulário</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maincapt.ui" line="8022"/>
        <source>Calcular o vocabulário do corpus</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
